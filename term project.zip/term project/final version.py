from cmu_112_graphics import *
import os, time, random

##############################################################################
#               background 

#https://twitter.com/lowkekops/status/1261672132297121792
#https://www.shutterstock.com/image-vector
# /city-park-scenes-game-background-suitable-495158818
#https://en.wikipedia.org/wiki/Star#/media/File:Starsinthesky.jpg
#https://theconversation.com/literature-sheds-light-on-the-history-and
# -mystery-of-the-southern-ocean-122664

def background(app):
    path = "background"
    scale = [1.5,0.9,0.9,0.9]
    background = []
    i = 0 
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,scale[i])
        background.append(pic)
        i += 1 
    return background

####################################################################
#                player

# motions 
#https://www.fightersgeneration.com/characters2/marco-metalslug-a2.html
# same site for running and shooting motion 

def playermotion(app):
    key = ["nomover","nomovel","runr","runl",
           "shootr","shootl"]
    path = ["nomove","run","shoot"]
    motion = dict()
    i = 0 
    for name in path:
        file = os.listdir(name)
        rt = root = name + '/'+file[0]
        textr = key[i]
        textl = key[i+1]
        motion[textr] = app.loadImage(root)
        motion[textl] = app.loadImage(root).transpose(Image.FLIP_LEFT_RIGHT)
        i +=2
    return motion

################################################
#http://pixelartmaker.com/art/9d5278583d9297d
#http://pixelartmaker.com/art/63e15ad4a99ac13
#http://pixelartmaker.com/art/a5a2ef86d697e69

def bullets(app):
    path = "bullet"
    bullet = dict()
    scale = [0.3,0.3,0.05,0.05,0.2,0.2]
    key = ["1l","1r","2l","2r","3l","3r"]
    i = 0 
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,scale[i])
        keyl = key[i]
        bullet[keyl] = pic
        picr = app.loadImage(rt).transpose(Image.FLIP_LEFT_RIGHT)
        keyr = key[i+1]
        picr = app.scaleImage(picr,scale[i+1])
        bullet[keyr] = picr
        i += 2
    return bullet

###################################################################
#      rebel 
# http://www.lowgif.com/view.html

def rebelmotion(app):
    path = ["rebelmoving","rebelshooting"]
    key = ["movingl","movingr","shootingl","shootingr"]
    i = 0 
    rebel = dict()
    for name in path:
        file = os.listdir(name)
        rt  = name + '/'+file[0]
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,0.7)
        name = key[i]
        rebel[name] = pic
        picl = app.loadImage(rt).transpose(Image.FLIP_LEFT_RIGHT)
        picl = app.scaleImage(picl,0.7)
        name = key[i+1]
        rebel[name] = picl
        i += 2 
    return rebel

def rebels(app,x):
    enemy= rebel(x, app.height*0.78)
    return enemy

def distance(x1,y1,x2,y2):
    dist = ((x1-x2)**2 + (y1-y2)**2)**0.5
    return dist 

class rebel(object):
    def __init__(self,x,y):
        self.x = x 
        self.y = y 
        self.hp = 40
    def checkingplayer(self,targetx,targety):
        alert = 300
        if distance(self.x,self.y,targetx,targety) <= alert:
            return True
        else:
            return False 

##############################################################################
######################
## no moving rebel
#http://randomhoohaas.flyingomelette.com/msmia/1/ug.html

def steadyrebel(app):
    path = "soldiersteady"
    soldier = []
    for file in os.listdir(path):
        rt = path+'/' + file
        pic = app.loadImage(rt).transpose(Image.FLIP_LEFT_RIGHT)
        pic = app.scaleImage(pic,2)
        soldier.append(pic)
    return soldier 

###### #########
##### create no moving rebel

def srebel(app):
    x = app.width*5/2 
    enemy = rebel(x+50, app.height*0.2)
    return enemy

##############################################################################
##################################
### Boss 
#https://metalslug.fandom.com/wiki/Crablops for form1 & form2 
def crabform1(app):
    path = "crabform1"
    crab = []
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,1.5)
        crab.append(pic)
    return crab

def crabform2(app):
    path = "crabform2"
    crab = []
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,1.5)
        crab.append(pic)
    return crab
####################################
######### app data 

def appStarted(app):
    # player 
    app.motioni = 0 
    app.x = app.width/4
    app.cx = app.width/4
    app.y = app.height*0.79
    app.playerhp = 100
    app.time = time.time()
    app.move = False
    app.moveright = True
    app.playermotion = playermotion(app)
    app.shoot = False
    app.bullets = bullets(app)
    app.playerbullet = app.bullets["3r"]
    app.playerbulletcoordir = []
    app.playerbulletcoordil = []
    app.dx = 50
    app.dy = 50
    # background 
    app.scenes = background(app)
    app.map = app.scenes[0] 
    #http://pixelartmaker.com/art/02e44c9e0f40b8b
    grass = app.loadImage("grass.png")
    app.grass = app.scaleImage(grass,0.3)
    # rebels 
    x = app.width*7/4
    app.rebel = rebels(app,x)
    app.rebelmotions = rebelmotion(app)
    app.rebelmotion = app.rebelmotions["movingr"]
    app.rebelsbullet = app.bullets["2l"]
    app.rebelsbulletcoordil = []
    app.rebelsbulletcoordir = []
    app.rebeli = 0 
    # NEW ADD STEADY REBEL
    app.srebelmotion = steadyrebel(app)
    app.srebel = srebel(app)
    app.srebelcounter = 0
    app.srebelbullet = app.bullets["2l"]
    app.srebelbulletcoordi = []
    app.bulletdx = -25
    app.bulletdy = 0
    app.srebeli = 0 
    # boss
    app.boss = False
    app.bossx = app.width/2
    app.bossy = app.height/2 
    app.bossmotion = crabform1(app)
    app.bosscounter = 0 
    app.bossbullet1 = app.bullets["1r"]
    app.bossbullet1coordi = {"1lu":[],"1ld":[],"1ru":[],"1rd":[]}
    app.bossbullet2coordi = {"1lu":[],"1ld":[],"1ru":[],"1rd":[]}
    app.bosshp = 1000
    app.bossdx = 20
    app.bossdy = 20 
    app.bossbdx = 20
    app.bossbdy = 10
    app.i = 0 
    ### general setting 
    app.started = False 
    app.level = 1 
    app.continu = False 
    app.sett = False 
    #https://www.greenmangaming.com/blog/the-timeless-perfection-of-metal-slug/
    imagecover = app.loadImage("cover.jpg")
    app.imagecover = app.scaleImage(imagecover, 2/3)
    #http://pixelartmaker.com/art/6a45404d913e6d1
    startb = app.loadImage("start.png")
    app.startb = app.scaleImage(startb, 1/3)
    #http://pixelartmaker.com/art/8acb9305a104342
    setting = app.loadImage("setting.png")
    app.setting = app.scaleImage(setting,0.14)
    #http://pixelartmaker.com/art/d176c44ae0d9ffd
    back = app.loadImage("back.png")
    app.backb = app.scaleImage(back,0.14)
    #http://pixelartmaker.com/art/a76b4c16ac01572
    mapbutton = app.loadImage("mapbutton.png")
    app.mapbutton = app.scaleImage(mapbutton,0.14)
    app.mapset = False
    # scroll 
    app.scrollX = 0
    app.scrollMargin = app.width*3/4
    # map box
    #http://pixelartmaker.com/art/808527fb299dba0
    frame = app.loadImage("box.png")
    app.frame = app.scaleImage(frame,1/3)
    #http://pixelartmaker.com/art/b81027c3d32458c
    textbox = app.loadImage("textbox.png")
    app.textbox = app.scaleImage(textbox,0.9)

#############################################################
#####   timer fired helper 

def movebullet(dx,dy,L):
    result = []
    for x,y in L:
        newx = x + dx
        newy = y + dy
        result.append((newx,newy))
    return result

def removebullet(L,width):
    result = []
    for x,y in L:
        if  0 < x <= width*4/5:
            result.append((x,y))
    return result 

def shootingboss(app,L):
    for key in L:
        if len(L[key]) < 5:
            L[key].append((app.bossx,app.bossy))
    return L 

def checkleft(app,L):
    grassx, grassy = app.width/2 +75, app.height*0.4
    widthy = 20
    widthx = 130
    for x,y in L:
        if x < 30 or (( grassy - widthy < y < grassy + widthy) and 
        (grassx + widthx> x > grassx - widthx)):
            return True
    return False

def checkbottom(app,L):
    for x,y in L:
        if y > app.height - 50:
            return True
    return False

def checktopright(app,L):
    for x,y in L:
        if x > app.width:
            return True
    return False

#####################
## boss

def checkboundary(app,L):
    for key in L:
        for x,y in L[key]:
            if x < 30 or x > app.width-30:
                return True
        return False

def checktopbo(app,L):
    for key in L:
        for x,y in L[key]:
            if y < 30 or y > app.height-30:
                return True
        return False    

def findMax(d):
    guess = None
    count = -1
    for key in d:
        value = d[key]
        if value > count:
            count = value 
            guess = key
    if count == 0:
        guess = "nomove"
    return guess
        
def bossAI(app):
    damagecount = dict()
    for move in ["up","left","right"]:
        x = app.bossx 
        y = app.bossy
        i = 0
        damage = 0 
        bossbullet1prediction = {"1lu":[],"1ld":[],"1ru":[],"1rd":[]}
        dx = 20
        dy = 10      
        # shooting simulation 
        if move == 'up':
            y -= app.bossdy
        elif move == "left":
            x -= app.bossdx
        elif move == "right":
            x += app.bossdx
        for key in bossbullet1prediction:
            if len(bossbullet1prediction[key]) < 5:    
                bossbullet1prediction[key].append((x,y))
        while i != 50:
            # bullet moving simulation 
            if checkboundary(app,bossbullet1prediction):
                    dx = - dx
            if checktopbo(app,bossbullet1prediction):
                    dy = - dy
            bossbullet1prediction["1lu"] = movebullet(-1.5*dx,-dy,
                                   bossbullet1prediction["1lu"])
            bossbullet1prediction["1ru"] = movebullet(dx,-dy,
                                   bossbullet1prediction["1ru"])   
            bossbullet1prediction["1ld"] = movebullet(-1.5*dx, dy,
                                   bossbullet1prediction["1ld"])
            bossbullet1prediction["1rd"] = movebullet(dx, dy,
                                   bossbullet1prediction["1rd"])
            for key in bossbullet1prediction:
                ####damage count 
                for x, y in bossbullet1prediction[key]:
                    if app.x - 10 < x < app.x+10 and (app.y - 25 < y < app.y+ 25):
                        damage += 2
            i += 1
        damagecount[move] = damage
    decision = findMax(damagecount)
    return decision    

###################################
def bossAI2(app):
    damagecount = dict()
    for move in ["up","down","left","right"]:
        x = app.bossx 
        y = app.bossy
        i = 0
        damage = 0 
        bossbullet2prediction = {"1lu":[],"1ld":[],"1ru":[],"1rd":[]}
        dx = 20
        dy = 10      
        # shooting simulation
        if move =="up":
            y -= app.bossdy
        elif move == 'down':
            y += app.bossdy
        elif move == "left":
            x -= app.bossdx
        elif move == "right":
            x += app.bossdx
        for key in bossbullet2prediction:
            if len(bossbullet2prediction[key]) < 5:    
                bossbullet2prediction[key].append((x,y))
        while i != 20:
            # bullet moving simulation 
            if checkboundary(app,bossbullet2prediction):
                    dx = - dx
            if checktopbo(app,bossbullet2prediction):
                    dy = - dy
            bossbullet2prediction["1lu"] = movebullet(-1.5*dx,dy,
                                   bossbullet2prediction["1lu"])
            bossbullet2prediction["1ru"] = movebullet(1.5*dx, dy,
                                   bossbullet2prediction["1ru"])   
            bossbullet2prediction["1ld"] = movebullet(-dx, dy,
                                   bossbullet2prediction["1ld"])
            bossbullet2prediction["1rd"] = movebullet(dx,  dy,
                                   bossbullet2prediction["1rd"])
            for key in bossbullet2prediction:
                ####damage count 
                for x, y in bossbullet2prediction[key]:
                    if app.x - 10 < x < app.x+10 and (app.y - 25 < y < app.y+ 25):
                        damage += 3
            i += 1
        damagecount[move] = damage
    decision = findMax(damagecount)
    return decision    

##########################
### timer fired 
def timerFired(app):
    if app.move:
        app.motioni += 1
        #timemove = time.time()
        if app.motioni == 1:
            app.move = False
            app.motioni = 0 
    elif app.shoot: 
        app.motioni +=1 
        if app.motioni == 2:
            app.shoot = False
            app.motioni = 0 

    # shooting bullet within the range 
    app.playerbulletcoordir = movebullet(25,0,app.playerbulletcoordir)
    app.playerbulletcoordir = removebullet(app.playerbulletcoordir,
                                           app.width)# by shooting range 
    app.playerbulletcoordil = movebullet(-25,0,app.playerbulletcoordil)
    app.playerbulletcoordil = removebullet(app.playerbulletcoordil,
                                           app.width)# by the shooting range 
    # gravity 
    if app.y < app.height*0.79:
        app.y += 20

########################################################
#            Rebel AI 
    currentx = app.rebel.x - app.scrollX
    app.rebelsbulletcoordil = movebullet(-30,0, app.rebelsbulletcoordil)
    app.rebelsbulletcoordir = movebullet(30,0, app.rebelsbulletcoordir)
    if app.rebel.hp > 0 and app.boss == False:
        if app.rebel.checkingplayer(app.x,app.y):
            if app.x < app.rebel.x:
                app.rebelmotion = app.rebelmotions["shootingl"]
                app.rebelsbullet = app.bullets["2l"]
                if len(app.rebelsbulletcoordil) <3:
                    app.rebelsbulletcoordil.append((currentx -15,
                    app.rebel.y))
            else:
                app.rebelmotion = app.rebelmotions["shootingr"]
                app.rebelsbullet = app.bullets["2r"]
                if len(app.rebelsbulletcoordir) <3:
                    app.rebelsbulletcoordir.append((currentx + 15,
                    app.rebel.y))
        else:      
            if 200 < app.rebel.x - app.scrollX < 500:
                step = 0 
                if app.rebeli%3:
                    step = random.randrange(-30,30)
                app.rebel.x -= step
                if step <=0:
                    app.rebelmotion = app.rebelmotions["movingr"]
                else:
                    app.rebelmotion = app.rebelmotions["movingl"]

            elif app.rebel.x - app.scrollX >= 500:
                app.rebel.x -=10

            elif app.rebel.x - app.scrollX <= 300:
                app.rebel.x += 10
        app.rebeli +=1 
    if app.rebeli == 12 or app.rebel.hp <0:
        app.rebelsbulletcoordil = []
        app.rebelsbulletcoordir = []
        app.rebeli = 0
    #print(app.rebelsbulletcoordil,app.rebelsbulletcoordir)

########################################################
#   Rebel  HP check 
#  playerdamage 
    for x,y in app.playerbulletcoordir:
        x = x + app.scrollX
        if app.x < app.rebel.x < x and (app.rebel.y - 35 < y < app.rebel.y+ 35):
            app.rebel.hp -= 20

    for x,y in app.playerbulletcoordil:
        x = x + app.scrollX
        if (x < app.rebel.x < app.x) and (app.rebel.y - 35 < y < app.rebel.y+ 35):
            app.rebel.hp -= 20

# rebeldamage
    #print(app.rebelsbulletcoordil)
    for x,y in app.rebelsbulletcoordir:
        x = x + app.scrollX
        if app.rebel.x < app.x < x and (app.y - 20 < y < app.y+ 20):
            app.playerhp -= 1
    for x,y in app.rebelsbulletcoordil:
        x = x + app.scrollX

        if app.rebel.x > app.x > x and (app.y - 20 < y < app.y+ 20):
            app.playerhp -= 1

############# steady rebel AI

    currentsx = app.srebel.x - app.scrollX
    if checktopright(app,app.srebelbulletcoordi):
        app.bulletdx = -50
        app.bulletdy = 0 
        app.srebelbulletcoordi = []

    if app.srebel.checkingplayer(app.x,app.y):
        app.srebelcounter = (1 + app.srebelcounter) % len(app.srebelmotion)
        if len(app.srebelbulletcoordi) < 5:
            app.srebelbullet = app.bullets["2l"]
            app.srebelbulletcoordi.append((currentsx-35, app.srebel.y+18))
    else:
        app.srebelcounter = 0 

    app.srebelbulletcoordi = movebullet(app.bulletdx,app.bulletdy,
                            app.srebelbulletcoordi)

    if checkleft(app,app.srebelbulletcoordi):
        app.bulletdx = 10
        app.bulletdy = 20
        app.srebelbullet = app.bullets["2r"]

    elif checkbottom(app,app.srebelbulletcoordi):
        app.bulletdx = 10
        app.bulletdy = -20
        app.srebelbullet = app.bullets["2r"]
    
    elif checktopright(app,app.srebelbulletcoordi) or app.srebel.hp <0:
        app.srebelbulletcoordi = []
        app.bulletdx = -50
        app.bulletdy = 0 

#################################
#### HP count 
    # player hit 
    for x,y in app.playerbulletcoordir:
        x = x + app.scrollX
        if app.x < app.srebel.x < x and (app.srebel.y - 35 < y < app.srebel.y+ 35):
           app.srebel.hp -= 30

    for x,y in app.playerbulletcoordil:
        x = x + app.scrollX
        if (x < app.srebel.x < app.x) and (app.srebel.y - 35 < y < app.srebel.y+ 35):
            app.srebel.hp -= 30

    # srebel hit Changed from moving soldier 
    for x,y in app.srebelbulletcoordi:
        x = x + app.scrollX
        if app.x - 10 < x < app.x+10 and (app.y - 20 < y < app.y+ 20):
            app.playerhp -= 2        

#################################
############ boss AI 

    # boss motion 
    if app.boss == True:
        app.bosscounter = (1 + app.bosscounter) % len(app.bossmotion)
    ##### bullet type 1:
    ## going up:
        app.i +=1 
        if app.bosshp > 500:
            if distance(app.bossx,app.bossy,app.x,app.y) < 300:
                app.bossbullet1coordi = shootingboss(app,app.bossbullet1coordi)

            app.bossbullet1coordi["1lu"] = movebullet(-1.5*(app.bossbdx),-(app.bossbdy),
                                        app.bossbullet1coordi["1lu"])
            app.bossbullet1coordi["1ru"] = movebullet((app.bossbdx),-(app.bossbdy),
                                        app.bossbullet1coordi["1ru"])   
            app.bossbullet1coordi["1ld"] = movebullet(-1.5*(app.bossbdx),(app.bossbdy),
                                        app.bossbullet1coordi["1ld"])
            app.bossbullet1coordi["1rd"] = movebullet((app.bossbdx),(app.bossbdy),
                                        app.bossbullet1coordi["1rd"])
            
            if checkboundary(app,app.bossbullet1coordi):
                app.bossbdx = - app.bossbdx
            if checktopbo(app,app.bossbullet1coordi):
                app.bossbdy = - app.bossbdy

            if app.i == 50:
                app.bossbullet1coordi["1lu"] = []
                app.bossbullet1coordi["1ru"] = []
                app.bossbullet1coordi["1ld"] = []
                app.bossbullet1coordi["1rd"] = []
                app.bossbdx = 20
                app.bossbdy = 10
                app.i = 0
            if app.bossy < app.height/2:
                app.bossy += 15
            if app.bossy < 100:
                app.bossdy = 0 
        
            if 100 < app.bossx < app.width - 100 and 150 < app.bossy < app.height -150:
                decision = bossAI(app)
                if decision == "up":
                    app.bossy -= app.bossdy
                elif decision == "left":
                    app.bossx -= app.bossdx
                elif decision == "right":
                    app.bossx += app.bossdx

        else: # form 2 
            # reset the boss
            i = 0
            app.bossmotion = crabform2(app)
            app.bossbullet1coordi["1lu"] = []
            app.bossbullet1coordi["1ru"] = []
            app.bossbullet1coordi["1ld"] = []
            app.bossbullet1coordi["1rd"] = []  
            # keep shooting   
            app.bossbullet2coordi = shootingboss(app,app.bossbullet2coordi)
            app.bossbullet2coordi["1lu"] = movebullet(-1.5*(app.bossbdx),(app.bossbdy),
                                        app.bossbullet2coordi["1lu"])
            app.bossbullet2coordi["1ru"] = movebullet((1.5*app.bossbdx), (app.bossbdy),
                                        app.bossbullet1coordi["1ru"])   
            app.bossbullet2coordi["1ld"] = movebullet(-(app.bossbdx),(app.bossbdy),
                                        app.bossbullet2coordi["1ld"])
            app.bossbullet2coordi["1rd"] = movebullet((app.bossbdx),(app.bossbdy),
                                        app.bossbullet2coordi["1rd"])
            if 100 < app.bossx < app.width - 100 and 50 < app.bossy < app.height:
                decision = bossAI2(app)
                if decision == "down":
                    app.bossy += app.bossdy
                elif decision == "up":
                    app.bossy -= app.bossdy 
                elif decision == "left":
                    app.bossx -= app.bossdx
                elif decision == "right":
                    app.bossx += app.bossdx

            if checkboundary(app,app.bossbullet2coordi):
                app.bossbdx = - app.bossbdx
            if checktopbo(app,app.bossbullet2coordi):
                app.bossbdy = - app.bossbdy

            if app.i == 20:
                app.bossbullet2coordi["1lu"] = []
                app.bossbullet2coordi["1ru"] = []
                app.bossbullet2coordi["1ld"] = []
                app.bossbullet2coordi["1rd"] = []
                app.bossbdx = 20
                app.bossbdy = 10
                app.i = 0
            if app.bossy >= app.height/2:
                app.bossy -= 30
            elif app.bossy < 75:
                app.bossy += 50
        if app.bossx < 100:
            app.bossx += 100
        elif app.bossx > app.width - 100:
            app.bossx -= 20 
    ################################
        # Boss damage count 
        if app.bosshp > 500:
            for key in app.bossbullet1coordi:
                for x, y in app.bossbullet1coordi[key]:
                    if app.x - 10 < x < app.x+10 and (app.y - 25 < y < app.y+ 25):
                        app.playerhp -= 2
        else:
            for key in app.bossbullet2coordi:
                for x, y in app.bossbullet2coordi[key]:
                    if app.x - 10 < x < app.x+10 and (app.y - 25 < y < app.y+ 25):
                        app.playerhp -= 3       
        
        for x,y in app.playerbulletcoordir:
            if app.x < app.bossx < x and (app.bossy - 50 < y < app.bossy+ 50):
                app.bosshp -= 10

        for x,y in app.playerbulletcoordil:
            if (x < app.bossx < app.x) and (app.bossy - 100 < y < app.bossy+ 100):
                app.bosshp -= 10

####################################################
###          mouse pressed Helper 

def isinside(L,x,y):
    x1,x2,y1,y2 = L[0],L[1],L[2],L[3]
    if x1 <= x <= x2 and y1 <= y <=y2:
        return True
    else:
        return False

def mapchoice(width,height,framewidth,frameheight):
    result = []
    for i in range(4):
        x1 = width/2 - framewidth/2
        x2 = width/2 + framewidth/2 
        y1 = height*(i+1)/5 - frameheight/2
        y2 = height*(i+1)/5 + frameheight/2
        result.append([int(x1),int(x2),int(y1),int(y2)])
    return result 

#############################################
## mouse pressed

def mousePressed(app,event):
    x = event.x
    y = event.y
    start = [218, 317, 259,293]
    sett= [484, 524, 341, 380]
    back = [35, 69, 23,55]
    mapp = [216,317,93,170]
    framewidth = 142
    frameheight = 59

    choices = mapchoice(app.width,app.height,framewidth,frameheight)

    choice1,choice2,choice3,choice4 = choices[0],choices[1],choices[2],choices[3]

    if isinside(start,x,y) and app.sett == False:
        app.started = True

    elif isinside(sett,x,y):
        app.sett = True 
    
    elif isinside(back,x,y):
        if app.mapset == True:
            app.mapset = False
        else:
            app.sett = False

    # map setting options 
    elif isinside(mapp,x,y):
        app.mapset = True
    if app.mapset == True and isinside(choice1,x,y):
        app.map = app.scenes[0]
    elif app.mapset == True and isinside(choice2,x,y):
        app.map = app.scenes[1]
    elif app.mapset == True and isinside(choice3,x,y):
        app.map = app.scenes[2]
    elif app.mapset == True and isinside(choice4,x,y):
        app.map = app.scenes[3]

##########################################################

#https://www.cs.cmu.edu/~112/notes/notes-animations-part4.html
def makePlayerVisible(app):
    # scroll to make player visible as needed
    if (app.x < app.scrollX + app.scrollMargin):
        app.scrollX = app.x - app.scrollMargin

    if (app.x > app.scrollX + app.width - app.scrollMargin):
        app.scrollX = app.x - app.width + app.scrollMargin

#https://www.cs.cmu.edu/~112/notes/notes-animations-part4.html

def movePlayer(app, dx, dy):
    app.x += dx
    app.y += dy
    makePlayerVisible(app)

############################################################
## key press

def keyPressed(app,event):
    cx = app.x - app.scrollX
    if event.key == "r":
        appStarted(app)

    elif event.key == "Right":
        app.motioni = 0 
        app.cx -= app.scrollX # current app.x on screen 
        app.move = True
        app.moveright = True
        app.shoot = False

        if app.boss == False:
            movePlayer(app, app.dx, 0)
        elif app.boss == True and 30 < app.x < app.width-50:
            app.x += app.dx

    elif event.key == "Left":
        app.motioni = 0 
        app.move = True
        app.moveright = False
        app.shoot = False
        if app.boss == False:
            movePlayer(app, -app.dx, 0)
        elif app.boss == True and 40 < app.x < app.width-40:
            app.x -= app.dx
            
    elif event.key == "b":
        app.boss = True 

    elif event.key == "Up" and app.shoot == False:
        app.y -= 80

    elif event.key == "s":
        app.motioni = 0 
        app.shoot = True

        if app.moveright:
            app.playerbullet = app.bullets["3r"]
            app.playerbulletcoordir.append((cx+15,app.y-21))
        else:
            app.playerbullet = app.bullets["3l"]
            app.playerbulletcoordil.append((cx-15,app.y-21))
    else:
        app.move = False
        app.shoot = False
    # enter the boss fight 
    if app.x >= 1750:
        app.boss = True
        app.x = 50
        app.scrollX = 0 
        app.scrollMargin = 0  

#####################################################
### drawing info

def drawsettinginfo(app,canvas):
    canvas.create_image(app.width/2, app.height/3,
    image=ImageTk.PhotoImage(app.mapbutton))

def mapchoices(app,canvas):
    texts = ["Default","City Park",
             "Stars","Ocean"]
    for i in range(4):
        x = app.width/2 
        y = app.height*(i+1)/5
        canvas.create_image(x, y,
        image=ImageTk.PhotoImage(app.frame))
        canvas.create_text(x,y,
        text = texts[i],font = "Itatly 20")

#############################
##   map 

def mapgeneration(app,canvas,x):
    for i in range(4):
        canvas.create_image(x+i*533, app.height/2, 
        image=ImageTk.PhotoImage(app.map))

def grassdraw(app,canvas,x,width):
    ### Grass on the ground 
    for i in range(19):
        cx = width*(i-2)+x
        cy = app.height*0.95
        canvas.create_image(cx,cy,
        image = ImageTk.PhotoImage(app.grass))

# NEW ADD Grass Above Ground with steady rebel
def grassky(app,canvas,x):
    canvas.create_image(app.width*5/2+75 - x,app.height*0.4,
    image = ImageTk.PhotoImage(app.grass))

#################
##  draw player

def drawplayer(app,canvas):
    cx = app.x
    cx -= app.scrollX
    if app.shoot == False:
        # no move facing right 
        if (app.move == False) and (app.moveright == True):
            motion = app.playermotion["nomover"]
        # no move facing left 
        elif (app.move == False) and (app.moveright == False):
            motion = app.playermotion["nomovel"]
        # run toward right 
        elif (app.move == True) and (app.moveright == True):
            motion = app.playermotion["runr"]
        # run toward left 
        elif (app.move == True) and (app.moveright == False):
            motion = app.playermotion["runl"]
    # shooting toward right 
    elif (app.shoot == True) and (app.moveright == True):
        motion = app.playermotion["shootr"]

    # shooting to left 
    elif (app.shoot == True) and (app.moveright == False):
        motion = app.playermotion["shootl"]

    canvas.create_image(cx, app.y, image=ImageTk.PhotoImage(motion))

    # draw player bullet
    for x,y in app.playerbulletcoordir:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.playerbullet))
    for x,y in app.playerbulletcoordil:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.playerbullet))

################################
### draw moving rebel
def drawrebel(app,canvas):
    canvas.create_image(app.rebel.x - app.scrollX,app.rebel.y,
    image=ImageTk.PhotoImage(app.rebelmotion))
    for x,y in app.rebelsbulletcoordir:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.rebelsbullet))

    for x,y in app.rebelsbulletcoordil:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.rebelsbullet))

#####  draw the non-moving rebel 
def drawsrebel(app,canvas,scroll):
    sprite = app.srebelmotion[app.srebelcounter]
    canvas.create_image(app.srebel.x - scroll, app.srebel.y,
    image = ImageTk.PhotoImage(sprite))
    ## draw bullet 
    for x, y in app.srebelbulletcoordi:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.srebelbullet))


######################################
#### starting menu
def drawstartmenu(app,canvas):

    # starting 
    canvas.create_image(app.width/2, app.height*0.7, 
    image=ImageTk.PhotoImage(app.startb))
    # setting
    canvas.create_image(app.width*0.95, app.height*0.9, 
    image=ImageTk.PhotoImage(app.setting))  

######################
####  new boss draw 
def drawboss(app,canvas):
    bossmove = app.bossmotion[app.bosscounter]
    canvas.create_image(app.bossx,app.bossy,
    image=ImageTk.PhotoImage(bossmove))
    for key in app.bossbullet1coordi:
        if key == "1ru" or key == "1rd":
            bullet = app.bullets["1r"]
        else:
            bullet = app.bullets["1l"]
        for x,y in app.bossbullet1coordi[key]:
                canvas.create_image(x,y,
                image=ImageTk.PhotoImage(bullet))

    for key in app.bossbullet2coordi:

        if key == "1ru" or key == "1rd":
            bullet = app.bullets["1r"]
        else:
            bullet = app.bullets["1l"]
        for x,y in app.bossbullet2coordi[key]:
                canvas.create_image(x,y,
                image=ImageTk.PhotoImage(bullet))

########################
# draw the hp of the player 

def drawhp(app,canvas):
    percentage = app.playerhp / 100
    x1 = 20
    y1 = 20 
    x2 = 100
    y2 = 40
    width = 80
    canvas.create_rectangle(x1,y1,x2,y2)
    if percentage > 0.2:
        color = "green"
    else:
        color = "red"
    canvas.create_rectangle(x1,y1,x1+width*percentage,y2,fill = color)


##########################
# Ending 

def drawending(app,canvas):
    canvas.create_image(app.width/2, app.height/2, 
    image=ImageTk.PhotoImage(app.imagecover))

    canvas.create_image(app.width/2, app.height/2, 
    image=ImageTk.PhotoImage(app.textbox))
    if app.bosshp < 0:
        text = "You Win!! Press R to Restart"
        color = "black"
    elif app.playerhp < 0:
        text = "Try Again!! Press R to Restart"
        color = "red"

    canvas.create_text(app.width/2, app.height*0.4, 
    text = text, font = "Arial 20 bold",
    fill = color)


def redrawAll(app,canvas):
    
    if app.started == False:
        canvas.create_image(app.width/2, app.height/2, 
        image=ImageTk.PhotoImage(app.imagecover)) # background 
        if app.sett == False:
            drawstartmenu(app,canvas)
        else:
            canvas.create_image(app.width*0.1, app.height*0.1, 
            image=ImageTk.PhotoImage(app.backb))
            if app.mapset == False:
                drawsettinginfo(app,canvas)

            elif app.mapset == True:
                mapchoices(app,canvas)

    elif app.started == True:
        cx = app.x
        cx -= app.scrollX
        x = app.width/2 - app.scrollX
        width = 135 # the width of grass
        # draw the background
        mapgeneration(app,canvas,x)
        grassdraw(app,canvas,x,width)
        grassky(app,canvas,app.scrollX)
        if app.rebel.hp > 0:
            drawrebel(app,canvas)
        if app.srebel.hp > 0 :
            drawsrebel(app,canvas,app.scrollX)
        if app.boss and app.bosshp>0:
            drawboss(app,canvas)
        if app.playerhp > 0:
            drawplayer(app,canvas)
        drawhp(app,canvas)
    if app.playerhp< 0 or app.bosshp <0:
        drawending(app,canvas)

runApp(width= 533, height = 400)