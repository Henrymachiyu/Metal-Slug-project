from cmu_112_graphics import *
import os, time, random

def bullets(app):
    path = "bullet"
    bullet = dict()
    scale = [0.3,0.3,0.05,0.05,0.2,0.2]
    key = ["1l","1r","2l","2r","3l","3r"]
    i = 0 
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,scale[i])
        keyl = key[i]
        bullet[keyl] = pic
        picr = app.loadImage(rt).transpose(Image.FLIP_LEFT_RIGHT)
        keyr = key[i+1]
        picr = app.scaleImage(picr,scale[i+1])
        bullet[keyr] = picr
        i += 2
    return bullet


###################################################################
#      rebel 

def rebelmotion(app):
    path = ["rebelmoving","rebelshooting"]
    key = ["movingl","movingr","shootingl","shootingr"]
    i = 0 
    rebel = dict()
    for name in path:
        file = os.listdir(name)
        rt  = name + '/'+file[0]
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,0.7)
        name = key[i]
        rebel[name] = pic
        picl = app.loadImage(rt).transpose(Image.FLIP_LEFT_RIGHT)
        picl = app.scaleImage(picl,0.7)
        name = key[i+1]
        rebel[name] = picl
        i += 2 
    return rebel

def rebels(app):
    x = app.width*3/4
    enemy= rebel(x, app.height*0.78)
    return enemy

def distance(x1,y1,x2,y2):
    dist = ((x1-x2)**2 + (y1-y2)**2)**0.5
    return dist 

class rebel(object):
    def __init__(self,x,y):
        self.x = x 
        self.y = y 
        self.hp = 40
    def checkingplayer(self,targetx,targety):
        alert = 250
        if distance(self.x,self.y,targetx,targety) <= alert:
            return True
        else:
            return False 

##############################################################################
#               background 
def background(app):
    path = "background"
    scale = [1.5,0.9,0.9,0.9]
    background = []
    i = 0 
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,scale[i])
        background.append(pic)
        i += 1 
    return background

####################################################################
#                player

# motions 
def playermotion(app):
    key = ["nomover","nomovel","runr","runl",
           "shootr","shootl"]
    path = ["nomove","run","shoot"]
    motion = dict()
    i = 0 
    for name in path:
        file = os.listdir(name)
        rt = root = name + '/'+file[0]
        textr = key[i]
        textl = key[i+1]
        motion[textr] = app.loadImage(root)
        motion[textl] = app.loadImage(root).transpose(Image.FLIP_LEFT_RIGHT)
        i +=2
    return motion

################################################
def appStarted(app):
    app.boss = False 
    # player 
    app.x = app.width/4
    app.y = app.height*0.79
    app.playerhp = 100
    app.time = time.time()
    app.move = False
    app.moveright = True
    app.playermotion = playermotion(app)
    app.shoot = False
    app.bullets = bullets(app)
    app.playerbullet = app.bullets["3r"]
    app.playerbulletcoordir = []
    app.playerbulletcoordil = []
    app.dx = 50
    app.dy = 50
    # background 
    app.scenes = background(app)
    app.map = app.scenes[0] 
    grass = app.loadImage("grass.png")
    app.grass = app.scaleImage(grass,0.3)
    # rebels 
    app.rebel = rebels(app)
    app.rebelmotions = rebelmotion(app)
    app.rebelmotion = app.rebelmotions["movingr"]
    app.rebelsbullet = app.bullets["2l"]
    app.rebelsbulletcoordil = []
    app.rebelsbulletcoordir = []

#####################################
def movebullet(dx,dy,L):
    result = []
    for x,y in L:
        newx = x + dx
        newy = y + dy
        result.append((newx,newy))
    return result

def timerFired(app):
    if app.move:
        #timemove = time.time()
        if int(time.time())%1 ==0:
            app.move = False
    elif app.shoot: 
        if int(time.time())% 1 == 0:
            app.shoot = False

    app.playerbulletcoordir = movebullet(25,0,app.playerbulletcoordir)
    app.playerbulletcoordil = movebullet(-25,0,app.playerbulletcoordil)
    if app.y < app.height*0.79:
        app.y += 20
        
########################################################
#            Rebel AI 
    app.rebelsbulletcoordil = movebullet(-30,0, app.rebelsbulletcoordil)
    app.rebelsbulletcoordir = movebullet(30,0, app.rebelsbulletcoordir)
    if app.rebel.hp > 0 and app.boss == False:
        if app.rebel.checkingplayer(app.x,app.y):
            if app.x < app.rebel.x:
                app.rebelmotion = app.rebelmotions["shootingl"]
                app.rebelsbullet = app.bullets["2l"]
                if int(time.time())%2 ==0:
                    app.rebelsbulletcoordil.append((app.rebel.x-15,app.rebel.y))
            else:
                app.rebelmotion = app.rebelmotions["shootingr"]
                app.rebelsbullet = app.bullets["2r"]
                if int(time.time())%2 ==0:
                    app.rebelsbulletcoordir.append((app.rebel.x+15,app.rebel.y))
        else:      
            if 200 < app.rebel.x < 500:
                step = 0 
                if int(time.time())%2:
                    step = random.randrange(-30,30)
                app.rebel.x -= step
                if step <=0:
                    app.rebelmotion = app.rebelmotions["movingr"]
                else:
                    app.rebelmotion = app.rebelmotions["movingl"]

            elif app.rebel.x >= 500:
                app.rebel.x -=10

            elif app.rebel.x <= 300:
                app.rebel.x += 10

########################################################
#     HP check 
#  playerdamage 
    for x,y in app.playerbulletcoordir:
        if app.x < app.rebel.x < x and (app.rebel.y - 35 < y < app.rebel.y+ 35):
            app.rebel.hp -= 1

    for x,y in app.playerbulletcoordil:
        if (x < app.rebel.x < app.x) and (app.rebel.y - 35 < y < app.rebel.y+ 35):
            app.rebel.hp -= 1

# rebeldamage
    #print(app.rebelsbulletcoordil)
    for x,y in app.rebelsbulletcoordir:
        #print(app.rebel.x > app.x > x and (app.y - 50 < y < app.y+ 50))
        if app.rebel.x < app.x < x and (app.y - 20 < y < app.y+ 20):
            app.playerhp -= 0.1
    for x,y in app.rebelsbulletcoordil:
        #print(app.rebel.x > app.x > x and (app.y - 50 < y < app.y+ 50))
        if app.rebel.x > app.x > x and (app.y - 20 < y < app.y+ 20):
            app.playerhp -= 0.1

########################
def keyPressed(app,event):
    #app.time = time.time()
    if event.key == "r":
        appStarted(app)
    elif event.key == "Right":
        app.move = True
        app.moveright = True
        app.shoot = False
        app.playerbullet = app.bullets["3r"]
        app.x += app.dx
    elif event.key == "Left":
        app.playerbullet = app.bullets["3l"]
        app.move = True
        app.moveright = False
        app.shoot = False
        app.x -= app.dx
    elif event.key == "Up" and app.shoot == False:
        app.y -= 80
    elif event.key == "s":
        app.shoot = True
        if app.moveright:
            app.playerbulletcoordir.append((app.x+15,app.y-21))
        else:
            app.playerbulletcoordil.append((app.x-15,app.y-21))
    else:
        app.move = False
        app.shoot = False

###################################################################
# graph functions 

def mapgeneration(app,canvas):

    canvas.create_image(app.width/2, app.height/2, 
    image=ImageTk.PhotoImage(app.map))

def grassdraw(app,canvas,x,width):
    for i in range(5):
        cx = width*(i-2)+x
        cy = app.height*0.95
        canvas.create_image(cx,cy,
        image = ImageTk.PhotoImage(app.grass))

def drawplayer(app,canvas):
    if app.shoot == False:
        # no move facing right 
        if (app.move == False) and (app.moveright == True):
            motion = app.playermotion["nomover"]
        # no move facing left 
        elif (app.move == False) and (app.moveright == False):
            motion = app.playermotion["nomovel"]
        # run toward right 
        elif (app.move == True) and (app.moveright == True):
            motion = app.playermotion["runr"]
        # run toward left 
        elif (app.move == True) and (app.moveright == False):
            motion = app.playermotion["runl"]
    # shooting toward right 
    elif (app.shoot == True) and (app.moveright == True):
        motion = app.playermotion["shootr"]

    # shooting to left 
    elif (app.shoot == True) and (app.moveright == False):
        motion = app.playermotion["shootl"]

    canvas.create_image(app.x, app.y, image=ImageTk.PhotoImage(motion))
    # draw player bullet
    for x,y in app.playerbulletcoordir:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.playerbullet))
    for x,y in app.playerbulletcoordil:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.playerbullet))

def drawrebel(app,canvas):
    canvas.create_image(app.rebel.x,app.rebel.y,
    image=ImageTk.PhotoImage(app.rebelmotion))

    for x,y in app.rebelsbulletcoordir:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.rebelsbullet))

    for x,y in app.rebelsbulletcoordil:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.rebelsbullet))

#######################################
def redrawAll(app,canvas):
    width = 135
    x = app.width/2
    mapgeneration(app,canvas)
    grassdraw(app,canvas,x,width)
    if app.playerhp > 0:
        drawplayer(app,canvas)
    if app.rebel.hp >0:
        drawrebel(app,canvas)



runApp(width= 533, height = 400)

