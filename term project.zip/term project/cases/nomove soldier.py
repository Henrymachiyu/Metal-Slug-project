from cmu_112_graphics import *
import os, time, random


############################
#  no change from moving soldier 
def bullets(app):
    path = "bullet"
    bullet = dict()
    scale = [0.3,0.3,0.05,0.05,0.2,0.2]
    key = ["1l","1r","2l","2r","3l","3r"]
    i = 0 
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,scale[i])
        keyl = key[i]
        bullet[keyl] = pic
        picr = app.loadImage(rt).transpose(Image.FLIP_LEFT_RIGHT)
        keyr = key[i+1]
        picr = app.scaleImage(picr,scale[i+1])
        bullet[keyr] = picr
        i += 2
    return bullet

########
# no moving rebel session 
########

######################
## NEW ADD no moving rebel

def steadyrebel(app):
    path = "soldiersteady"
    soldier = []
    for file in os.listdir(path):
        rt = path+'/' + file
        pic = app.loadImage(rt).transpose(Image.FLIP_LEFT_RIGHT)
        pic = app.scaleImage(pic,2)
        soldier.append(pic)
    return soldier 

###### #########
#####  no change rebel 

def distance(x1,y1,x2,y2):
    dist = ((x1-x2)**2 + (y1-y2)**2)**0.5
    return dist 

class rebel(object):
    def __init__(self,x,y):
        self.x = x 
        self.y = y 
        self.hp = 40
    def checkingplayer(self,targetx,targety):
        alert = 250
        if distance(self.x,self.y,targetx,targety) <= alert:
            return True
        else:
            return False 

##### changed 

def srebel(app):
    x = app.width/2 
    enemy = rebel(x+50, app.height*0.2)
    return enemy

##############################################################################
#               background 
def background(app):
    path = "background"
    scale = [1.5,0.9,0.9,0.9]
    background = []
    i = 0 
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,scale[i])
        background.append(pic)
        i += 1 
    return background

####################################################################
#                player  no change from moving soldier 

# motions 
def playermotion(app):
    key = ["nomover","nomovel","runr","runl",
           "shootr","shootl"]
    path = ["nomove","run","shoot"]
    motion = dict()
    i = 0 
    for name in path:
        file = os.listdir(name)
        rt = root = name + '/'+file[0]
        textr = key[i]
        textl = key[i+1]
        motion[textr] = app.loadImage(root)
        motion[textl] = app.loadImage(root).transpose(Image.FLIP_LEFT_RIGHT)
        i +=2
    return motion

#####################
# no rebel 
def appStarted(app):
    app.boss = False 
    # player 
    app.x = app.width/4
    app.y = app.height*0.79
    app.playerhp = 100
    app.time = time.time()
    app.move = False
    app.moveright = True
    app.playermotion = playermotion(app)
    app.shoot = False
    app.bullets = bullets(app)
    app.playerbullet = app.bullets["3r"]
    app.playerbulletcoordir = []
    app.playerbulletcoordil = []
    app.dx = 50
    app.dy = 0
    # background 
    app.scenes = background(app)
    app.map = app.scenes[0] 
    grass = app.loadImage("grass.png")
    app.grass = app.scaleImage(grass,0.3)
    # NEW ADD STEADY REBEL
    app.srebelmotion = steadyrebel(app)
    app.srebel = srebel(app)
    app.srebelcounter = 0
    app.srebelbullet = app.bullets["2l"]
    app.srebelbulletcoordi = []
    app.bulletdx = -25
    app.bulletdy = 0

#####################################
# no change 
def movebullet(dx,dy,L):
    result = []
    for x,y in L:
        newx = x + dx
        newy = y + dy
        result.append((newx,newy))
    return result

### ADD new for no moving shooter 

def checkleft(app,L):
    grassx, grassy = app.width/2 +75, app.height*0.4
    widthy = 20
    widthx = 130
    for x,y in L:
        if x < 30 or (( grassy - widthy < y < grassy + widthy) and 
        (grassx + widthx> x > grassx - widthx)):
            return True
    return False

def checkbottom(app,L):
    for x,y in L:
        if y > app.height - 50:
            return True
    return False

def checktopright(app,L):
    for x,y in L:
        if x > app.width:
            return True
    return False

##############
# no rebel AI, damage check for player and rebel 
def timerFired(app):
    if app.move:
        #timemove = time.time()
        if int(time.time())%1 ==0:
            app.move = False
    elif app.shoot: 
        if int(time.time())% 1 == 0:
            app.shoot = False

    app.playerbulletcoordir = movebullet(25,0,app.playerbulletcoordir)
    app.playerbulletcoordil = movebullet(-25,0,app.playerbulletcoordil)
    if app.y < app.height*0.79:
        app.y += 20
    

############# Add steady rebel 

    if checktopright(app,app.srebelbulletcoordi):
        app.bulletdx = -50
        app.bulletdy = 0 
        app.srebelbulletcoordi = []

    if app.srebel.checkingplayer(app.x,app.y):
        app.srebelcounter = (1 + app.srebelcounter) % len(app.srebelmotion)
        if len(app.srebelbulletcoordi) < 5:
            app.srebelbullet = app.bullets["2l"]
            app.srebelbulletcoordi.append((app.srebel.x-35, app.srebel.y+18))
    else:
        app.srebelcounter = 0 

    app.srebelbulletcoordi = movebullet(app.bulletdx,app.bulletdy,
                            app.srebelbulletcoordi)

    if checkleft(app,app.srebelbulletcoordi):
        app.bulletdx = 10
        app.bulletdy = 20
        app.srebelbullet = app.bullets["2r"]

    elif checkbottom(app,app.srebelbulletcoordi):
        app.bulletdx = 10
        app.bulletdy = -20
        app.srebelbullet = app.bullets["2r"]
    
    elif checktopright(app,app.srebelbulletcoordi) or app.srebel.hp<0:
        app.srebelbulletcoordi = []
        app.bulletdx = -50
        app.bulletdy = 0

#################################
#### HP count 
    # player hit 
    for x,y in app.playerbulletcoordir:
        if app.x < app.srebel.x < x and (app.srebel.y - 35 < y < app.srebel.y+ 35):
           app.srebel.hp -= 30
    for x,y in app.playerbulletcoordil:
        if (x < app.srebel.x < app.x) and (app.srebel.y - 35 < y < app.srebel.y+ 35):
            app.srebel.hp -= 30

    # srebel hit Changed from moving soldier 
    for x,y in app.srebelbulletcoordi:
        if app.x - 10 < x < app.x+10 and (app.y - 20 < y < app.y+ 20):
            app.playerhp -= 0.1

########################
# no change from moving 
def keyPressed(app,event):
    #app.time = time.time()
    if event.key == "r":
        appStarted(app)
    elif event.key == "Right":
        app.move = True
        app.moveright = True
        app.shoot = False
        app.playerbullet = app.bullets["3r"]
        app.x += app.dx
    elif event.key == "Left":
        app.playerbullet = app.bullets["3l"]
        app.move = True
        app.moveright = False
        app.shoot = False
        app.x -= app.dx
    elif event.key == "Up" and app.shoot == False:
        app.y -= 80
    elif event.key == "s":
        app.shoot = True
        if app.moveright:
            app.playerbulletcoordir.append((app.x+15,app.y-21))
        else:
            app.playerbulletcoordil.append((app.x-15,app.y-21))
    else:
        app.move = False
        app.shoot = False

###################################################################
# graph functions 
# no draw rebel 

def mapgeneration(app,canvas):

    canvas.create_image(app.width/2, app.height/2, 
    image=ImageTk.PhotoImage(app.map))

def grassdraw(app,canvas,x,width):
    ### Grass on the ground 
    for i in range(5):
        cx = width*(i-2)+x
        cy = app.height*0.95
        canvas.create_image(cx,cy,
        image = ImageTk.PhotoImage(app.grass))

# NEW ADD Grass Above Ground with steady rebel
def grassky(app,canvas,x,width):
    canvas.create_image(x+75,app.height*0.4,
    image = ImageTk.PhotoImage(app.grass))
    
##### New Added draw srebel 
def drawsrebel(app,canvas):
    sprite = app.srebelmotion[app.srebelcounter]
    canvas.create_image(app.srebel.x,app.srebel.y,
    image = ImageTk.PhotoImage(sprite))
    ## draw bullet 
    for x, y in app.srebelbulletcoordi:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.srebelbullet))

def drawplayer(app,canvas):
    if app.shoot == False:
        # no move facing right 
        if (app.move == False) and (app.moveright == True):
            motion = app.playermotion["nomover"]
        # no move facing left 
        elif (app.move == False) and (app.moveright == False):
            motion = app.playermotion["nomovel"]
        # run toward right 
        elif (app.move == True) and (app.moveright == True):
            motion = app.playermotion["runr"]
        # run toward left 
        elif (app.move == True) and (app.moveright == False):
            motion = app.playermotion["runl"]
    # shooting toward right 
    elif (app.shoot == True) and (app.moveright == True):
        motion = app.playermotion["shootr"]

    # shooting to left 
    elif (app.shoot == True) and (app.moveright == False):
        motion = app.playermotion["shootl"]

    canvas.create_image(app.x, app.y, image=ImageTk.PhotoImage(motion))

    # draw player bullet
    for x,y in app.playerbulletcoordir:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.playerbullet))
    for x,y in app.playerbulletcoordil:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.playerbullet))

#######################################
def redrawAll(app,canvas):
    width = 135
    x = app.width/2
    mapgeneration(app,canvas)
    grassdraw(app,canvas,x,width)
    grassky(app,canvas,x,width)
    if app.playerhp > 0:
        drawplayer(app,canvas)
    if app.srebel.hp >0:
        drawsrebel(app,canvas)


runApp(width= 533, height = 400)