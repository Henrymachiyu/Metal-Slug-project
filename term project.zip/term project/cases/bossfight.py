from cmu_112_graphics import *
import os, time, random


############################
#  no change from moving soldier 
def bullets(app):
    path = "bullet"
    bullet = dict()
    scale = [0.3,0.3,0.05,0.05,0.2,0.2]
    key = ["1l","1r","2l","2r","3l","3r"]
    i = 0 
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,scale[i])
        keyl = key[i]
        bullet[keyl] = pic
        picr = app.loadImage(rt).transpose(Image.FLIP_LEFT_RIGHT)
        keyr = key[i+1]
        picr = app.scaleImage(picr,scale[i+1])
        bullet[keyr] = picr
        i += 2
    return bullet

##################################
### Added Boss 

#https://metalslug.fandom.com/wiki/Crablops
def crabform1(app):
    path = "crabform1"
    crab = []
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,1.5)
        crab.append(pic)
    return crab
def crabform2(app):
    path = "crabform2"
    crab = []
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,1.5)
        crab.append(pic)
    return crab

def distance(x1,y1,x2,y2):
    dist = ((x1-x2)**2 + (y1-y2)**2)**0.5
    return dist 
##############################################################################
#               background 
def background(app):
    path = "background"
    scale = [1.5,0.9,0.9,0.9]
    background = []
    i = 0 
    for file in os.listdir(path):
        rt = path + '/' + file
        pic = app.loadImage(rt)
        pic = app.scaleImage(pic,scale[i])
        background.append(pic)
        i += 1 
    return background

####################################################################
#                player

# motions 
def playermotion(app):
    key = ["nomover","nomovel","runr","runl",
           "shootr","shootl"]
    path = ["nomove","run","shoot"]
    motion = dict()
    i = 0 
    for name in path:
        file = os.listdir(name)
        rt = root = name + '/'+file[0]
        textr = key[i]
        textl = key[i+1]
        motion[textr] = app.loadImage(root)
        motion[textl] = app.loadImage(root).transpose(Image.FLIP_LEFT_RIGHT)
        i +=2
    return motion

################################################
def appStarted(app):
    app.boss = False 
    # player 
    app.x = app.width/4
    app.y = app.height*0.79
    app.playerhp = 100
    app.time = time.time()
    app.move = False
    app.moveright = True
    app.playermotion = playermotion(app)
    app.shoot = False
    app.bullets = bullets(app)
    app.playerbullet = app.bullets["3r"]
    app.playerbulletcoordir = []
    app.playerbulletcoordil = []
    app.dx = 50
    app.dy = 50
    # background 
    app.scenes = background(app)
    app.map = app.scenes[0] 
    grass = app.loadImage("grass.png")
    app.grass = app.scaleImage(grass,0.3)
    # boss
    app.boss = True # false in the game 
    app.bossx = app.width/2
    app.bossy = app.height/2 
    app.bossmotion = crabform1(app)
    app.bosscounter = 0 
    app.bossbullet1 = app.bullets["1r"]
    app.bossbullet1coordi = {"1lu":[],"1ld":[],"1ru":[],"1rd":[]}
    app.bossbullet2coordi = {"1lu":[],"1ld":[],"1ru":[],"1rd":[]}
    app.bosshp = 1000
    app.bossdx = 20
    app.bossdy = 20 
    app.bossbdx = 20
    app.bossbdy = 10
    app.i = 0 

#####################################
def movebullet(dx,dy,L):
    result = []
    for x,y in L:
        newx = x + dx
        newy = y + dy
        result.append((newx,newy))
    return result

def shootingboss(app,L):
    for key in L:
        if len(L[key]) < 5:
            L[key].append((app.bossx,app.bossy))
    return L 

### modified 
def checkboundary(app,L):
    for key in L:
        for x,y in L[key]:
            if x < 30 or x > app.width-30:
                return True
        return False

def checktopbo(app,L):
    for key in L:
        for x,y in L[key]:
            if y < 30 or y > app.height-30:
                return True
        return False    

def findMax(d):
    guess = None
    count = -1
    for key in d:
        value = d[key]
        if value > count:
            count = value 
            guess = key
    if count == 0:
        guess = "nomove"
    return guess
        
def bossAI(app):
    damagecount = dict()
    for move in ["up","left","right"]:
        x = app.bossx 
        y = app.bossy
        i = 0
        damage = 0 
        bossbullet1prediction = {"1lu":[],"1ld":[],"1ru":[],"1rd":[]}
        dx = 20
        dy = 10      
        # shooting simulation 
        if move == 'up':
            y -= app.bossdy
        #elif move == "down":
            #y += app.bossdy
        elif move == "left":
            x -= app.bossdx
        elif move == "right":
            x += app.bossdx
        for key in bossbullet1prediction:
            if len(bossbullet1prediction[key]) < 5:    
                bossbullet1prediction[key].append((x,y))
        while i != 50:
            # bullet moving simulation 
            if checkboundary(app,bossbullet1prediction):
                    dx = - dx
            if checktopbo(app,bossbullet1prediction):
                    dy = - dy
            bossbullet1prediction["1lu"] = movebullet(-1.5*dx,-dy,
                                   bossbullet1prediction["1lu"])
            bossbullet1prediction["1ru"] = movebullet(dx,-dy,
                                   bossbullet1prediction["1ru"])   
            bossbullet1prediction["1ld"] = movebullet(-1.5*dx, dy,
                                   bossbullet1prediction["1ld"])
            bossbullet1prediction["1rd"] = movebullet(dx, dy,
                                   bossbullet1prediction["1rd"])
            for key in bossbullet1prediction:
                ####damage count 
                for x, y in bossbullet1prediction[key]:
                    if app.x - 10 < x < app.x+10 and (app.y - 25 < y < app.y+ 25):
                        damage += 2
            i += 1
        damagecount[move] = damage
    decision = findMax(damagecount)
    return decision    

###################################
def bossAI2(app):
    damagecount = dict()
    for move in ["up","down","left","right"]:
        x = app.bossx 
        y = app.bossy
        i = 0
        damage = 0 
        bossbullet2prediction = {"1lu":[],"1ld":[],"1ru":[],"1rd":[]}
        dx = 20
        dy = 10      
        # shooting simulation
        if move =="up":
            y -= app.bossdy
        elif move == 'down':
            y += app.bossdy
        elif move == "left":
            x -= app.bossdx
        elif move == "right":
            x += app.bossdx
        for key in bossbullet2prediction:
            if len(bossbullet2prediction[key]) < 5:    
                bossbullet2prediction[key].append((x,y))
        while i != 20:
            # bullet moving simulation 
            if checkboundary(app,bossbullet2prediction):
                    dx = - dx
            if checktopbo(app,bossbullet2prediction):
                    dy = - dy
            bossbullet2prediction["1lu"] = movebullet(-1.5*dx,dy,
                                   bossbullet2prediction["1lu"])
            bossbullet2prediction["1ru"] = movebullet(1.5*dx, dy,
                                   bossbullet2prediction["1ru"])   
            bossbullet2prediction["1ld"] = movebullet(-dx, dy,
                                   bossbullet2prediction["1ld"])
            bossbullet2prediction["1rd"] = movebullet(dx,  dy,
                                   bossbullet2prediction["1rd"])
            for key in bossbullet2prediction:
                ####damage count 
                for x, y in bossbullet2prediction[key]:
                    if app.x - 10 < x < app.x+10 and (app.y - 25 < y < app.y+ 25):
                        damage += 3
            i += 1
        damagecount[move] = damage
    decision = findMax(damagecount)
    return decision    


###############################################
def timerFired(app):
    if app.move:
        #timemove = time.time()
        if int(time.time())%1 ==0:
            app.move = False
    elif app.shoot: 
        if int(time.time())% 1 == 0:
            app.shoot = False

    app.playerbulletcoordir = movebullet(25,0,app.playerbulletcoordir)
    app.playerbulletcoordil = movebullet(-25,0,app.playerbulletcoordil)
    if app.y < app.height*0.79:
        app.y += 20
    # boss motion 
    if app.boss == True:
        app.bosscounter = (1 + app.bosscounter) % len(app.bossmotion)
    
    ##### bullet type 1:
    ## going up:
    app.i +=1 
    if app.bosshp > 500:
        if distance(app.bossx,app.bossy,app.x,app.y) < 300:
            app.bossbullet1coordi = shootingboss(app,app.bossbullet1coordi)

        app.bossbullet1coordi["1lu"] = movebullet(-1.5*(app.bossbdx),-(app.bossbdy),
                                    app.bossbullet1coordi["1lu"])
        app.bossbullet1coordi["1ru"] = movebullet((app.bossbdx),-(app.bossbdy),
                                    app.bossbullet1coordi["1ru"])   
        app.bossbullet1coordi["1ld"] = movebullet(-1.5*(app.bossbdx),(app.bossbdy),
                                    app.bossbullet1coordi["1ld"])
        app.bossbullet1coordi["1rd"] = movebullet((app.bossbdx),(app.bossbdy),
                                    app.bossbullet1coordi["1rd"])
        
        if checkboundary(app,app.bossbullet1coordi):
            app.bossbdx = - app.bossbdx
        if checktopbo(app,app.bossbullet1coordi):
            app.bossbdy = - app.bossbdy

        if app.i == 50:
            app.bossbullet1coordi["1lu"] = []
            app.bossbullet1coordi["1ru"] = []
            app.bossbullet1coordi["1ld"] = []
            app.bossbullet1coordi["1rd"] = []
            app.bossbdx = 20
            app.bossbdy = 10
            app.i = 0
        if app.bossy < app.height/2:
            app.bossy += 15
        if app.bossy < 100:
            app.bossdy = 0 
    
        if 100 < app.bossx < app.width - 100 and 150 < app.bossy < app.height -150:
            decision = bossAI(app)
            if decision == "up":
                app.bossy -= app.bossdy
            elif decision == "left":
                app.bossx -= app.bossdx
            elif decision == "right":
                app.bossx += app.bossdx

    else: # form 2 
        # reset the boss
        i = 0
        app.bossmotion = crabform2(app)
        app.bossbullet1coordi["1lu"] = []
        app.bossbullet1coordi["1ru"] = []
        app.bossbullet1coordi["1ld"] = []
        app.bossbullet1coordi["1rd"] = []  
        # keep shooting   
        app.bossbullet2coordi = shootingboss(app,app.bossbullet2coordi)
        app.bossbullet2coordi["1lu"] = movebullet(-1.5*(app.bossbdx),(app.bossbdy),
                                    app.bossbullet2coordi["1lu"])
        app.bossbullet2coordi["1ru"] = movebullet((1.5*app.bossbdx), (app.bossbdy),
                                    app.bossbullet1coordi["1ru"])   
        app.bossbullet2coordi["1ld"] = movebullet(-(app.bossbdx),(app.bossbdy),
                                    app.bossbullet2coordi["1ld"])
        app.bossbullet2coordi["1rd"] = movebullet((app.bossbdx),(app.bossbdy),
                                    app.bossbullet2coordi["1rd"])
        if 100 < app.bossx < app.width - 100 and 50 < app.bossy < app.height:
            decision = bossAI2(app)
            if decision == "down":
                app.bossy += app.bossdy
            elif decision == "up":
                app.bossy -= app.bossdy 
            elif decision == "left":
                app.bossx -= app.bossdx
            elif decision == "right":
                app.bossx += app.bossdx

        if checkboundary(app,app.bossbullet2coordi):
            app.bossbdx = - app.bossbdx
        if checktopbo(app,app.bossbullet2coordi):
            app.bossbdy = - app.bossbdy

        if app.i == 20:
            app.bossbullet2coordi["1lu"] = []
            app.bossbullet2coordi["1ru"] = []
            app.bossbullet2coordi["1ld"] = []
            app.bossbullet2coordi["1rd"] = []
            app.bossbdx = 20
            app.bossbdy = 10
            app.i = 0
        if app.bossy >= app.height/2:
            app.bossy -= 30
        elif app.bossy < 75:
            app.bossy += 50
    if app.bossx < 100:
        app.bossx += 100
    elif app.bossx > app.width - 100:
        app.bossx -= 20 

################################
    # damage count 
    if app.bosshp > 500:
        for key in app.bossbullet1coordi:
            for x, y in app.bossbullet1coordi[key]:
                if app.x - 10 < x < app.x+10 and (app.y - 25 < y < app.y+ 25):
                    app.playerhp -= 2
    else:
        for key in app.bossbullet2coordi:
            for x, y in app.bossbullet2coordi[key]:
                if app.x - 10 < x < app.x+10 and (app.y - 25 < y < app.y+ 25):
                    app.playerhp -= 3       
    
    for x,y in app.playerbulletcoordir:
        if app.x < app.bossx < x and (app.bossy - 50 < y < app.bossy+ 50):
            app.bosshp -= 1

    for x,y in app.playerbulletcoordil:
        if (x < app.bossx < app.x) and (app.bossy - 100 < y < app.bossy+ 100):
            app.bosshp -= 1

########################
def keyPressed(app,event):
    #app.time = time.time()
    if event.key == "r":
        appStarted(app)
    elif event.key == "Right":
        app.move = True
        app.moveright = True
        app.shoot = False
        app.playerbullet = app.bullets["3r"]
        app.x += app.dx
    elif event.key == "Left":
        app.playerbullet = app.bullets["3l"]
        app.move = True
        app.moveright = False
        app.shoot = False
        app.x -= app.dx
    elif event.key == "Up" and app.shoot == False:
        app.y -= 80
    elif event.key == "s":
        app.shoot = True
        if app.moveright:
            app.playerbulletcoordir.append((app.x+15,app.y-21))
        else:
            app.playerbulletcoordil.append((app.x-15,app.y-21))
    else:
        app.move = False
        app.shoot = False

###################################################################
# graph functions 

def mapgeneration(app,canvas):

    canvas.create_image(app.width/2, app.height/2, 
    image=ImageTk.PhotoImage(app.map))

def grassdraw(app,canvas,x,width):
    for i in range(5):
        cx = width*(i-2)+x
        cy = app.height*0.95
        canvas.create_image(cx,cy,
        image = ImageTk.PhotoImage(app.grass))

def drawplayer(app,canvas):
    if app.shoot == False:
        # no move facing right 
        if (app.move == False) and (app.moveright == True):
            motion = app.playermotion["nomover"]
        # no move facing left 
        elif (app.move == False) and (app.moveright == False):
            motion = app.playermotion["nomovel"]
        # run toward right 
        elif (app.move == True) and (app.moveright == True):
            motion = app.playermotion["runr"]
        # run toward left 
        elif (app.move == True) and (app.moveright == False):
            motion = app.playermotion["runl"]
    # shooting toward right 
    elif (app.shoot == True) and (app.moveright == True):
        motion = app.playermotion["shootr"]

    # shooting to left 
    elif (app.shoot == True) and (app.moveright == False):
        motion = app.playermotion["shootl"]

    canvas.create_image(app.x, app.y, image=ImageTk.PhotoImage(motion))
    # draw player bullet
    for x,y in app.playerbulletcoordir:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.playerbullet))
    for x,y in app.playerbulletcoordil:
        canvas.create_image(x,y,
        image=ImageTk.PhotoImage(app.playerbullet))

######################
####  new boss draw 
def drawboss(app,canvas):
    bossmove = app.bossmotion[app.bosscounter]
    canvas.create_image(app.bossx,app.bossy,
    image=ImageTk.PhotoImage(bossmove))
    for key in app.bossbullet1coordi:
        if key == "1ru" or key == "1rd":
            bullet = app.bullets["1r"]
        else:
            bullet = app.bullets["1l"]
        for x,y in app.bossbullet1coordi[key]:
                canvas.create_image(x,y,
                image=ImageTk.PhotoImage(bullet))

    for key in app.bossbullet2coordi:

        if key == "1ru" or key == "1rd":
            bullet = app.bullets["1r"]
        else:
            bullet = app.bullets["1l"]
        for x,y in app.bossbullet2coordi[key]:
                canvas.create_image(x,y,
                image=ImageTk.PhotoImage(bullet))
   
#######################################
def redrawAll(app,canvas):
    width = 135
    x = app.width/2
    mapgeneration(app,canvas)
    grassdraw(app,canvas,x,width)
    if app.boss and app.bosshp>0:
        drawboss(app,canvas)
    if app.playerhp > 0:
        drawplayer(app,canvas)

runApp(width= 533, height = 400)