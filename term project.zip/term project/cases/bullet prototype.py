from cmu_112_graphics import *
import random, time

def appStarted(app):
    app.x = app.width/2
    app.y = app.height/2
    app.dx = 10 
    app.dy = 0
    
def timerFired(app):
    app.x -= app.dx
    app.y += app.dy 
    if app.x <= 30:
        app.dx = -5
        app.dy = 20     
    if app.y >= app.height - 30:
        app.dy = -10
    elif app.y == 30:
        app.dy = 20

def redrawAll(app,canvas):
    canvas.create_oval(app.x+30,app.y+30,app.x-30,app.y-30)



runApp(width= 400, height = 400)
