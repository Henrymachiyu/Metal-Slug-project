Name: Metal Slug by CMU graphics 
Author: Henry Ma 

Description:

This Project is a game that is based on Metal Slug. Player can click left, right, and up to move, while there 
is gravity in the game. The player is also to hit "s" key to shoot. The effective shooting range is 80% of the 
screen width The first type of rebel the player is going to see is a moving rebel. 
It is gonna randomly move back and forth to check if the player is within certain range. 
If it is, the rebel is going face the player and attack. The second type of rebel the player is going to see is the 
non-moving rebel. When the player is very close to the rebel, the rebel is going to shoot the bullet and the bullet
is going to bounce back and forth if the bullets hit any barriers. Lastly, there is a boss fight. The boss is going 
to calculate the best move to give the most damage to the player, and then move based on that. The boss is going to 
shoot to all directions, and the bullets is going to bounce if it hits the boundary. When the boss's health dropped
to 50%, it is going to change to form 2. In form 2, the boss is flying and shoot downward. A similar calculation of 
moves is made, and the bullet increases its damage to the player. Once the player defeated the boss or got defeated, 
the game is over, and can click "r" to restart. The game also allows player to set background at the front page under
the set button. 

To run the project, simply open the final version and run the code. 

There is no extra library that needs to be installed. 

The shortcut command is if player click key "b", the game is automatically set into the boss fight. 

Thank you